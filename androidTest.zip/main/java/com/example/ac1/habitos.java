package com.example.ac1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class habitos extends AppCompatActivity {

    EditText editNome, editDescricao;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_habitos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        editNome = findViewById(R.id.editTextText);
        editDescricao = findViewById(R.id.editTextText2);
        btnSalvar = findViewById(R.id.button3);

        btnSalvar.setOnClickListener(v -> {
            String nome = editNome.getText().toString();
            String descricao = editDescricao.getText().toString();
            String habitoCompleto = nome + " - " + descricao;

            Intent intent = new Intent();
            intent.putExtra("novoHabito", habitoCompleto);
            setResult(RESULT_OK, intent);
            finish();
        });

    }
}