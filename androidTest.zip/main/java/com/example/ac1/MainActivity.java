package com.example.ac1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnAdicionarHabito;
    Button btnCadastrodeHabitos;
    ListView listViewHabitos;
    ArrayList<String> habitosList;
    ArrayAdapter<String> habitosAdapter;

    private static final int REQUEST_CADASTRO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnAdicionarHabito = findViewById(R.id.button);
        listViewHabitos = findViewById(R.id.listViewHabitos);
        habitosList = new ArrayList<>();
        habitosAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, habitosList);

        listViewHabitos.setAdapter(habitosAdapter);

        btnAdicionarHabito.setOnClickListener(v -> {
            String novoHabito = "Novo Hábito " + (habitosList.size() + 1);
            habitosList.add(novoHabito);
            habitosAdapter.notifyDataSetChanged();
        });
        listViewHabitos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String habito = habitosList.get(position);
                Toast.makeText(MainActivity.this, "Hábito '" + habito + "' marcado como feito hoje!", Toast.LENGTH_SHORT).show();
                view.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
            }
        });
        listViewHabitos.setOnItemLongClickListener((parent, view, position, id) -> {
            String habito = habitosList.get(position);

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Excluir hábito")
                    .setMessage("Deseja excluir o hábito: '" + habito + "'?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        habitosList.remove(position);
                        habitosAdapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Hábito excluído!", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();

            return true;
        });
        btnCadastrodeHabitos = findViewById(R.id.button2);
        btnCadastrodeHabitos.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, habitos.class);
            startActivityForResult(intent, REQUEST_CADASTRO);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CADASTRO && resultCode == RESULT_OK) {
            if (data != null) {
                String novoHabito = data.getStringExtra("novoHabito");
                if (novoHabito != null && !novoHabito.isEmpty()) {
                    habitosList.add(novoHabito);
                    habitosAdapter.notifyDataSetChanged();
                }
            }
        }
    }
}